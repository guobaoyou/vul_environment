<?php
/*
  Plugin Name: IgniteUp
  Plugin URI: http://getigniteup.com
  Description: IgniteUp is a powerful plugin which allows you to keep your site on launchpad till ignite-up and to build amazing coming soon pages.
  Version: 3.4
  Author: Ceylon Systems
  Author URI: http://getigniteup.com
  License: GPLv2 or later
  Text Domain: igniteup
  Domain Path: /localization/
 */

require_once 'includes/core-import.php';
require_once 'includes/core-helpers.php';

new CSComingSoonCreator(__FILE__, '3.4');
