<div class="igniteup-banners align-right">
    <a href="http://getigniteup.com/templates/?utm_source=banner&utm_medium=get_templates&utm_campaign=plugin" target="_blank">
        <img src="<?php echo plugin_dir_url(CSCS_FILE) . 'includes/images/get-templates-1.jpg'; ?>" style="width:100%;"> 
    </a>
    <!--Add another--> 

    <a href="http://getigniteup.com/templates/?utm_source=banner&utm_medium=get_templates&utm_campaign=plugin" target="_blank">
	<div class="igniteup-promo-temp-wrapper">
	    <img class="igniteup-promo-temp igniteup-promo-temp-1" src="<?php echo plugins_url('includes/images/help-get-templates-1.jpg', CSCS_FILE); ?>">
	    <img class="igniteup-promo-temp igniteup-promo-temp-2" style="display: none;" src="<?php echo plugins_url('includes/images/help-get-templates-2.jpg', CSCS_FILE); ?>">
	    <img class="igniteup-promo-temp igniteup-promo-temp-3" style="display: none;" src="<?php echo plugins_url('includes/images/help-get-templates-3.jpg', CSCS_FILE); ?>">
	    <img class="igniteup-promo-temp igniteup-promo-temp-4" style="display: none;" src="<?php echo plugins_url('includes/images/help-get-templates-4.jpg', CSCS_FILE); ?>">
	</div>
    </a>
</div>
<div class="clearfix"></div>
